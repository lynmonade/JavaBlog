package collections;

public class EmptyTask extends Task {
  public EmptyTask() {}
  public String toString() { return ""; }
}
