package collections;

public enum Priority { HIGH, MEDIUM, LOW }