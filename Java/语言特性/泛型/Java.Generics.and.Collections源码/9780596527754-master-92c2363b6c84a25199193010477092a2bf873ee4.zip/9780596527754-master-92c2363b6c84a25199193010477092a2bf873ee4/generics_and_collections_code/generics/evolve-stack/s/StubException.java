import java.util.*;

class StubException extends UnsupportedOperationException {}
